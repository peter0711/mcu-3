from django.apps import AppConfig


class HotelapiConfig(AppConfig):
    name = 'hotelapi'
